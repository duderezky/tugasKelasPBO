/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas5_bangunDatar;

/**
 *
 * @author ACER
 */
public class BangunDatar {
    
    public void luas(){
        System.out.println("Menghitung luas bangun datar");  
    }
    
    public void keliling(){
        System.out.println("Menghitung keliling bangun datar");
    }

}
