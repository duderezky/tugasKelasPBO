/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas3_mobil;

/**
 *
 * @author ACER
 */
public class Main {
    public static void main(String[] args) {
        
        Mobil mbl1 = new Mobil("Honda", "SUV");
        Mobil mbl2 = new Mobil("Toyota", "sedan",2099);
        
    }
}
